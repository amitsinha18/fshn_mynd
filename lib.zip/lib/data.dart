class Data {
  int counter;

  Data({this.counter});
}
