class MathCard {
  int redColor = 0;
  int greenColor = 0;
  int blueColor = 0;
  double margin = 0;
  MathCard(int red, int green, int blue, double marginTop) {
    redColor = red;
    greenColor = green;
    blueColor = blue;
    margin = marginTop;
  }
}
